const express = require ("express")
const mongoose = require ('mongoose')
const cros = require ("cors")
const EmployeeModel=require('./models/Employee')

const app=express()
app.use(express.json())
app.use(cros())

mongoose.connect("copy connection string");/*copy connection string*/
app.post('/register', (req,res)=>{
    EmployeeModel.create(req.body)
    .then(employees => req.json(employees))
    .catch(err => res.json(err))
})

app.listen(5173, ()=>{
    console.log("server is running")
})