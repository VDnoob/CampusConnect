import react from 'react'
function login (){
    return(
        <div>
            Login
        </div>
    )
}
export default Login;